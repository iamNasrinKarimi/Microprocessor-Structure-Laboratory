// ketabkhane haye morede niaz ra tarif mikonim
#include <mega128.h>
#include <delay.h>
#include <alcd.h>
#include <stdio.h>
// moteghayer haye morede niaz ra tarif mikonim
int m=0; //counter
int flag_sos=0;
void key_check(void);// tabe chek kilid ha
int  temp=0 ;// moteghayer haye dama 
 // areye haye LCD
char b[16];
char c[16];
char d[16];
void sos_key(void);
int door=0;// flag dar
void olaviat(void);// tabe olaviat
void fan_heater(void);//tabe fan va heater
void harekat_bck(void); // ahrekat be paein
void lcd_temp(void);  // LCD va namayeshe dama va baghie moteghayer ha
void harekat_fow(void); // tabeh harekat ro be bala
//unsigned long int counter=0;
int tabaghe=0;  // state tabaghe ra moshakhas mikonad 
int key_tabaghe_g=0 ,key_tabaghe_1=0,key_tabaghe_2=0,key_tabaghe_3=0,key_tabaghe_4=0 ;// flag haye kilid

int harekat_state=1; // state harekate asansor ra moshakhas mikonad

// Voltage Reference: Int., cap. on AREF
#define ADC_VREF_TYPE ((1<<REFS1) | (1<<REFS0) | (1<<ADLAR))

// Read the 8 most significant bits
// of the AD conversion result
unsigned char read_adc(unsigned char adc_input)
{
ADMUX=adc_input | ADC_VREF_TYPE;
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=(1<<ADSC);
// Wait for the AD conversion to complete
while ((ADCSRA & (1<<ADIF))==0);
ADCSRA|=(1<<ADIF);
return ADCH;
}

void main(void)
{
DDRB=0XFF;
DDRC=0XE0;
PORTC=0X1F;
DDRD=0X00;
PORTD=0XFF;
DDRE=0XFF;
DDRG=0XFF;


// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
// ADC initialization
// ADC Clock frequency: 500/000 kHz
// ADC Voltage Reference: Int., cap. on AREF
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=ADC_VREF_TYPE;
ADCSRA=(1<<ADEN) | (0<<ADSC) | (0<<ADFR) | (0<<ADIF) | (0<<ADIE) | (1<<ADPS2) | (0<<ADPS1) | (0<<ADPS0);
SFIOR=(0<<ACME);


TCNT1 = 0;        /* Set timer1 count zero */
    ICR1 = 2499;        /* Set TOP count for timer1 in ICR1 register */

    /* Set Fast PWM, TOP in ICR1, Clear OC1A on compare match, clk/64 */

TCCR1A = (1<<WGM11)|(1<<COM1A1);

TCCR1B = (1<<WGM12)|(1<<WGM13)|(1<<CS10)|(1<<CS11);
OCR1A=187;



// Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTA Bit 0
// RD - PORTA Bit 1
// EN - PORTA Bit 2
// D4 - PORTA Bit 4
// D5 - PORTA Bit 5
// D6 - PORTA Bit 6
// D7 - PORTA Bit 7
// Characters/line: 16
lcd_init(16);
 #asm("sei")
// Global enable interrupts
// Timer 0 overflow interrupt service routine
//interrupt [TIM0_OVF] void timer0_ovf_isr(void)
//{
//// Reinitialize Timer 0 value
//
//TCNT0=0xB2;
//// Place your code here
//  counter+=1;
//}

///////////////////////////while/////////////////////////
while(1){
    lcd_temp();
    olaviat(); 
    //PORTB.6=1;
    //sos_key();
      
}



// payane void
}
/////////////////////////tavabe////////////////////////

// olaviat tabe manteghe aslie code mast
void olaviat(void){
     
    key_check();//in tabe kelid ha ra check mikonad
    sos_key();// check kardane kelide sos
    if((key_tabaghe_g==0) && (key_tabaghe_1==0) && (key_tabaghe_2==0) && (key_tabaghe_3==0) && (key_tabaghe_4==0)){
    // asansor dar yek tabaghe stop mikone ta dokme bezanan
    sos_key();// check kardane kelide sos        
    }
    //dar paein shart haye harekat kardane asansor ra darim
    else{
        // baraye tabaghe g boodan varede shart zir mishavim
        if(tabaghe==0){
            //agar tabagheye maghsad morede nazar g bashad, bayad dar baz shavad 
            if(key_tabaghe_g==1){
                // inja bayad bege  esme tabaghe ro tabaghe        
                //dar baz beshe va baste beshe
                for(; m<500 ; m+=1){  
                    //OCR1A=300;//close
                    OCR1A=187;//open
                    key_check();
                    lcd_temp();
                    door=0;//dar baz mishe
                }                
                m=0;//shomarande sefr mishe
                key_tabaghe_g=0;// flag tabaghe g bayad khamoosh beshe
                harekat_state=1;// harekat state bayad be samte bala shavad
                PORTB.0=0;// LED tabaghe g bayad khamoosh beshe                              
            }
            //agar maghsad g nabashad varede shart zir mishavim
            else{
                // check mikone ke tabagh chandome maghsad
                if((key_tabaghe_1==1)|| (key_tabaghe_2==1) ||(key_tabaghe_3==1)||(key_tabaghe_4==1)){
                  // harekat be andaze yek tabaghe be samte bala 
                  harekat_fow();// tabe harekat ro be bala baraye yek tabaghe                        
                }
            }
        // payane shart haye tabaghe G
        }
        //tabaghe 1 agar bashim code varede shart zir mishavad
        else if(tabaghe==1){
            // age tabaghe 1 maghsad bashe varede shart zir mishe
            if(key_tabaghe_1==1){
                // inja bayad bege  esme tabaghe ro tabaghe        
                //dar baz beshe va baste beshe
                for(; m<500 ; m+=1){  
                    //OCR1A=300;//close
                    OCR1A=187;//open
                    key_check();
                    door=0;
                    lcd_temp();
                }// dar baz mishavad               
                m=0; // shomarande sefr mishe
                key_tabaghe_1=0;// flag tabaghe aval sefr mishe
                PORTC.5=0;PORTC.6=0;//motor bi harekat mishe
                OCR1A=187;// dar baz mishe vali in khat tekrarie yadam rafte pakesh konam :)            
                PORTB.1=0; //LED tabaghe aval khamoosh mishe    
            }
            // age maghsad tabaghe dige E bashe mire tu shart zir
            else{
                //check mikone bebine harekat state ro be balast ya paEn
                if(harekat_state==1){
                    // age be bala bood harekat, aval mibine ke maghsadesh aya tabaghe bala hast ya na
                    if( (key_tabaghe_2==1) ||(key_tabaghe_3==1)||(key_tabaghe_4==1)){
                       harekat_fow(); 
                    }
                    //age bashe ke mire bala va age na, miad state ro taghir mide ke bere paein ro check kone
                    else{
                        harekat_state=2;
                    }
                }
                // age harekat state be paein bashe, mire to shart zir
                else if(harekat_state==2){
                    //chek mikone bebine maghsad aya pen hast ya na?
                    if( key_tabaghe_g==1){
                        // harekat be andaze yek tabaghe be samte paein
                        harekat_bck(); 
                    }
                    //agar bood ke mire paein vali age nabood taghire state mide
                    else{
                        harekat_state=1;
                    }
                }
            } 
        //payene shart haye tabaghe aval    
        }
        //age dar tabaghe dovom bashim varede shart zir mishe
        else if(tabaghe==2){
            // age naghsad tabaghe dovom baghe mire tu shart zir
            if(key_tabaghe_2==1){
                // inja bayad bege  esme tabaghe ro tabaghe        
                //dar baz beshe va baste beshe
                for(; m<900 ; m+=1){  
                    //OCR1A=300;//close
                    OCR1A=187;//open
                    key_check();
                    door=0;// dar baz mishe
                    lcd_temp();
                }           
                m=0;//counter ro sefr mikone
                key_tabaghe_2=0;// flag tabaghe 2 sefr mishe 
                PORTB.2=0;//LED tabaghe dovom khamoosh mishe 
                OCR1A=187; // dar baz mishe     
            }
            // hala age maghsad tabaghe 2 nabashe vali dar tabaghe dovom bashim
            else{
                // chek mikone bebine state chie
                if(harekat_state==1){
                    // age state bala bood va maghsad tabaghe bala bood, mire to shart zir
                    if( (key_tabaghe_3==1) || (key_tabaghe_4==1) ){
                        // harekat be andaze yek tabaghe be samte bala 
                        harekat_fow(); 
                    }
                    // age na, state ro 2 mikone ke harekat ro be paein check baeshe
                    else{
                        harekat_state=2;
                    }
                }
                //age harekat ro be paein bashe,mire shart zir
                else if(harekat_state==2){ 
                    //age maghsad paien bashe mire paEn
                    if( (key_tabaghe_1==1) || (key_tabaghe_g==1)){
                        // harekat be andaze yek tabaghe be samte paein
                        harekat_bck(); 
                    }
                    // age na state ro 1 mikone ke bala raftan check beshe
                    else{
                        harekat_state=1;
                    }
                }
            }
        // shaert haye tabaghe 2 tamoom shod    
        }
        // age to tabaghe 3 bashim mire to shart zir
        else if(tabaghe==3){
            // age maghsad khode tabaghe 3 bashe 
            if(key_tabaghe_3==1){
                // inja bayad bege  esme tabaghe ro tabaghe        
                //dar baz beshe va baste beshe
                for(; m<500 ; m+=1){  
                    //OCR1A=300;//close
                    OCR1A=187;//open
                    key_check();
                    door=0;// dar baz mishe
                    lcd_temp();
                }                
                m=0;//counter sefr mishe
                key_tabaghe_3=0; // fals tabaghe sefr mishe
                PORTB.3=0;//LED  tabaghe 3 sefr mishe
                OCR1A=187;  // dar baz mishe   
            }
            else{
                // hala age maghdas tabaghe 3 nabashe,
                if(harekat_state==1){   
                    //age state bala bashe miad tabaghe haye bala ro chek mikone
                    if(key_tabaghe_4==1){
                        harekat_fow(); 
                    }
                    // age na miad state ro 2 mikone
                    else{
                        harekat_state=2;
                    }
                }
                // age state 2 bashe miad tabaghe haye paein ro check mikone
                else if(harekat_state==2){
                    // age maghsad paen bashe ke mire paein
                    if( (key_tabaghe_2==1) || (key_tabaghe_1==1) || (key_tabaghe_g==1)){
                        // harekat be andaze yek tabaghe be samte paein
                        harekat_bck();
                    }
                    //age na miad chek mikone state 2 ro
                    else{
                        harekat_state=1;
                    }
                }
            }
        // payene shart haye tabaghe 3 
        }
        // age to tabaghe 4 bashim shart zir ejra mishavad
        else if(tabaghe==4){
            // age maghsad tabaghe 4 bashe mire shart zir
            if(key_tabaghe_4==1){
                // inja bayad bege  esme tabaghe ro tabaghe        
                //dar baz beshe va baste beshe
                for(; m<500 ; m+=1){  
                    //OCR1A=300;//close
                    OCR1A=187;//open
                    key_check();
                    lcd_temp();
                    door=0;// dar baz mishe
                }
                m=0; // shomarande sefr mishe
                key_tabaghe_4=0;// flag sefr mishe
                PORTB.4=0;//LED roshan, khamoosh mishe baraye tabaghe4
                harekat_state=2;// state harekat 2 mishe ke bere faghat pein dige
                OCR1A=187; // dar baz mishe       
            }
            // chon tamame tabaghat ghaatan paein tar az 4 hastan, bayad tabaghe haye paein tar ro bayad check kone
            else if((key_tabaghe_3==1) || (key_tabaghe_2==1) || (key_tabaghe_1==1) || (key_tabaghe_g==1)){
                // harekat be andaze yek tabaghe be samte paein
                harekat_bck();                         
            }                
        }
        //payane shart haye tabaghe 4
    // payane shart haye harekat dar tabaghat 
    }
// payane tabe olaviate harekat
}

// in tabe etelaate LCD ra update mikonad
void lcd_temp(){
    temp=read_adc(0);// adc ra mikhanad va dar moteghayer mirizad
    sprintf(b,"%d",temp);// moteghayer ra be char tabdil mikonad
    //sprintf(a,"%d",j);
    sprintf(c,"%d",tabaghe);//moteghayer ra be char tabdil mikonad
    //sprintf(d,"%d",counter);
    //lcd_gotoxy(0,0);
    //lcd_puts("count:");
    //lcd_puts(d);
    lcd_gotoxy(0,1);// dar khat 0 1 minevisad
    lcd_puts("temp= ");// ebarete temp: ra chaap mikone
    lcd_gotoxy(0,7);// dar khat 0 7 minevisad
    lcd_puts(b);// meghdar temp ro minevise
    lcd_gotoxy(0,2);// dar khat 0 2 minevisad
    lcd_puts("tabaghe= ");// ebarete tabaghe: ra chaap mikone
    lcd_puts(c);  // meghdare tabaghe ra minevise
    lcd_gotoxy(0,3);// dar khat 0 3 minevisad
    lcd_puts("harekat= ");
    if(harekat_state==1){lcd_puts("fow");}// bala ye paen raftene asansor ra update mikonad
    if(harekat_state==2){lcd_puts("bak");}
    lcd_gotoxy(11,2);// dar khat 0 1 minevisad
    if(door==1){lcd_puts("cols");} // baz ya baste shodane dar ra update mikonad
    if(door==0){lcd_puts("open");}
    fan_heater();
    
}
// in tabe baraye fan va hiter ast ke ba tavajohe be meghdare dama an ha ra tanzim mikonad
void fan_heater(void){
    temp=read_adc(0);// ebteda meghdar giri mikonad
    if(temp>25){PORTE.5=0;PORTE.6=1;} // age dama bala bashe fan ra roshan mikonad
    else if(temp<20) {PORTE.5=1;PORTE.6=0;}// age dama paein bashe  heater ra roshan mikonad
    else {PORTE.5=0;PORTE.6=0;}// age garm beshe khamoosh mikone
    sos_key();// check kardane kelide sos
}

// in tabe kelid ha ro chek mikone va flag ha va LED ha ra update mikone
void key_check(void){
    // age kelidi zade beshe ke shamele tabaghe E ke tooshim nashe, flag va LEd ro roshan mikone
    sos_key();// check kardane kelide sos
    if(((PINC.0==0)||(PIND.0==0)) && (tabaghe!=0) ){
     key_tabaghe_g=1;//falg ro yek mikone
     PORTB.0=1;// LEd tabaghe ro roshan mikone
     }
     
     if(((PINC.1==0)||(PIND.1==0)) && (tabaghe!=1)){
     key_tabaghe_1=1;//falg ro yek mikone
     PORTB.1=1;// LEd tabaghe ro roshan mikone
     }
     if(((PINC.2==0)||(PIND.2==0)) && (tabaghe!=2)){
     key_tabaghe_2=1;//falg ro yek mikone
     PORTB.2=1; // LEd tabaghe ro roshan mikone
     }
     if(((PINC.3==0)||(PIND.3==0)) && (tabaghe!=3)){
     key_tabaghe_3=1; //falg ro yek mikone
     PORTB.3=1; // LEd tabaghe ro roshan mikone
     }
     if(((PINC.4==0)||(PIND.4==0)) && (tabaghe!=4)){
     key_tabaghe_4=1; //falg ro yek mikone
     PORTB.4=1;  // LEd tabaghe ro roshan mikone
     }
     
}

//in tabe bareye harekat be samte bala be ezaye 1 tabaghe be kar miravad
void harekat_fow(void){
    // ebteda chek mikone bebine dar baze ya na
    if(((key_tabaghe_g==1) || (key_tabaghe_1==1) || (key_tabaghe_2==1) || (key_tabaghe_3==1) || (key_tabaghe_4==1))&&(door==0)){
      // age dar baz bashe bayed dar ro bebandim
      for(; m<300 ; m+=1){  
        OCR1A=300;//close
        //OCR1A=187;//open
        key_check();
        door=1;// dar bashe mishe
        lcd_temp();
      }                          
      m=0;// counter sefr mishe  
    }
    lcd_temp();
    //delay 
    // dar inja be jaye dealy az yek fore estefade karde em
    //PORTB.6=1;
    for(; m<4000 ; m+=1){    
    //second=((m*5)/3999)+1;  
    sprintf(d,"%d",m);// shomarande ro minevise
    lcd_gotoxy(0,0);
    lcd_puts(d);
    key_check();// kelid ha dar harekat ham update mishe
    PORTC.5=1;PORTC.6=0;// ahrekat be bala
           
    } 
    fan_heater();//heater va fan check shavad 
    lcd_temp();
    m=0;// counter sefr mishe
    PORTC.5=0;PORTC.6=0;//motor stop
    // delay                    
    harekat_state=1;// state ra ro be bala taghir midahad
    tabaghe+=1; // shomare tabaghe ra ezafe mikonad
    //PORTB.6=0;

}

//in tabe bareye harekat be samte paein be ezaye 1 tabaghe be kar miravad
void harekat_bck(void){
    // aval check mikone ke dar baze ya baste
    if(((key_tabaghe_g==1) || (key_tabaghe_1==1) || (key_tabaghe_2==1) || (key_tabaghe_3==1) || (key_tabaghe_4==1))&&(door==0)){
      for(; m<300 ; m+=1){  
        OCR1A=300;//close
        //OCR1A=187;//open
        key_check();
        door=1;// dar ro mibande
        lcd_temp();
        fan_heater();//heater va fan check shavad
      }
      door=1;// flag dar ro yek mikone
      m=0;// counter ro 0 mikone  
    } 
    lcd_temp();
    //delay 
    // be jaye dealy az for estefade kardim
    for(; m<4000 ; m+=1){
        //second=((m*5)/3999)+1;  
        sprintf(d,"%d",m);// meghdar counter ro ro LCD minevise
        lcd_gotoxy(0,0);
        lcd_puts(d);
        key_check();
        PORTC.5=0;PORTC.6=1;// motor ro be bala
        
    } 
    lcd_temp();
        fan_heater();//heater va fan check shavad
    m=0;// counter ro seft mikone
    PORTC.5=0;PORTC.6=0;
    // delay
    harekat_state=2;// sate ro ro be paein mikone
    tabaghe-=1;  // tabaghe ro yeki kam mikone
}
//led sos
void sos_key(void){
   if(PIND.5==0){
    PORTE.0=1;
    PORTE.1=1;
    PORTE.2=1;
    PORTE.3=1;
    PORTE.4=1;
    flag_sos=1;  
   }
   else if(PIND.5==1){
    PORTE.0=0;
    PORTE.1=0;
    PORTE.2=0;
    PORTE.3=0;
    PORTE.4=0;
    flag_sos=0;  
   }
}




//////////////////////////////////////////////////////////////////